# TRAILHEAD Network Port

A simple browser-based, multiplayer off-road driving prototype inspired by the TRAILHEAD concept.

## Features
- Browser-based multiplayer
- Real-time player synchronization over Socket.IO
- Top-down driving physics
- Works in GitHub Codespaces

## Run locally
```bash
npm install
npm start