const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

app.use(express.static("public"));

const players = new Map();

function createPlayer(id) {
  return {
    id,
    x: 200 + Math.random() * 400,
    y: 200 + Math.random() * 400,
    angle: 0,
    speed: 0,
    color: randomColor(),
    inputs: {
      accelerate: false,
      brake: false,
      left: false,
      right: false
    }
  };
}

function randomColor() {
  const hue = Math.floor(Math.random() * 360);
  return `hsl(${hue}, 70%, 60%)`;
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

io.on("connection", (socket) => {
  const player = createPlayer(socket.id);
  players.set(socket.id, player);

  socket.emit("init", {
    id: socket.id,
    world: {
      width: 1600,
      height: 1200
    }
  });

  socket.on("input", (input) => {
    const p = players.get(socket.id);
    if (!p) return;

    p.inputs = {
      accelerate: !!input.accelerate,
      brake: !!input.brake,
      left: !!input.left,
      right: !!input.right
    };
  });

  socket.on("disconnect", () => {
    players.delete(socket.id);
  });
});

setInterval(() => {
  for (const player of players.values()) {
    const { inputs } = player;

    const maxSpeed = 260;
    const accel = 170;
    const brakeForce = 240;
    const friction = 40;
    const turnSpeed = 2.8;

    if (inputs.accelerate) {
      player.speed += accel * 0.016;
    } else if (inputs.brake) {
      player.speed -= brakeForce * 0.016;
    } else {
      player.speed -= friction * 0.016 * Math.sign(player.speed);
      if (Math.abs(player.speed) < 1) player.speed = 0;
    }

    player.speed = clamp(player.speed, -maxSpeed * 0.5, maxSpeed);

    if (Math.abs(player.speed) > 5) {
      const steering = (inputs.left ? 1 : 0) - (inputs.right ? 1 : 0);
      player.angle += steering * turnSpeed * 0.016 * (player.speed / 120 + 0.5);
    }

    player.x += Math.cos(player.angle) * player.speed * 0.016;
    player.y += Math.sin(player.angle) * player.speed * 0.016;

    // simple world bounds
    player.x = clamp(player.x, 40, 1560);
    player.y = clamp(player.y, 40, 1160);
  }

  io.emit("state", Array.from(players.values()));
}, 1000 / 60);

server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});