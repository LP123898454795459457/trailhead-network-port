const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const socket = io();

const localPlayer = {
  id: null,
  x: 0,
  y: 0,
  angle: 0,
  speed: 0,
  color: "#38bdf8"
};

const players = new Map();

const keys = {
  up: false,
  down: false,
  left: false,
  right: false
};

function sendInput() {
  socket.emit("input", {
    accelerate: keys.up,
    brake: keys.down,
    left: keys.left,
    right: keys.right
  });
}

window.addEventListener("keydown", (event) => {
  if (event.key === "ArrowUp" || event.key.toLowerCase() === "w") keys.up = true;
  if (event.key === "ArrowDown" || event.key.toLowerCase() === "s") keys.down = true;
  if (event.key === "ArrowLeft" || event.key.toLowerCase() === "a") keys.left = true;
  if (event.key === "ArrowRight" || event.key.toLowerCase() === "d") keys.right = true;
  sendInput();
});

window.addEventListener("keyup", (event) => {
  if (event.key === "ArrowUp" || event.key.toLowerCase() === "w") keys.up = false;
  if (event.key === "ArrowDown" || event.key.toLowerCase() === "s") keys.down = false;
  if (event.key === "ArrowLeft" || event.key.toLowerCase() === "a") keys.left = false;
  if (event.key === "ArrowRight" || event.key.toLowerCase() === "d") keys.right = false;
  sendInput();
});

socket.on("init", (state) => {
  localPlayer.id = state.id;
  localPlayer.color = "#38bdf8";
});

socket.on("state", (state) => {
  for (const p of state) {
    players.set(p.id, p);
    if (p.id === localPlayer.id) {
      localPlayer.x = p.x;
      localPlayer.y = p.y;
      localPlayer.angle = p.angle;
      localPlayer.speed = p.speed;
    }
  }

  // remove stale players
  for (const id of Array.from(players.keys())) {
    if (!state.some((p) => p.id === id)) {
      players.delete(id);
    }
  }
});

function drawCar(x, y, angle, color) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);

  ctx.fillStyle = color;
  ctx.fillRect(-16, -10, 32, 20);

  ctx.fillStyle = "#f8fafc";
  ctx.fillRect(10, -3, 8, 6);

  ctx.restore();
}

function drawTerrain() {
  ctx.fillStyle = "#162534";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  for (let i = 0; i < 24; i++) {
    const x = (i * 80) % canvas.width;
    const y = (i * 53) % canvas.height;
    ctx.fillStyle = i % 2 === 0 ? "#1f3d2d" : "#203b34";
    ctx.fillRect(x, y, 70, 70);
  }
}

function drawWorld() {
  const cameraX = localPlayer.x - canvas.width / 2;
  const cameraY = localPlayer.y - canvas.height / 2;

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawTerrain();

  ctx.save();
  ctx.translate(-cameraX, -cameraY);

  for (const p of players.values()) {
    drawCar(p.x, p.y, p.angle, p.color);
  }

  ctx.restore();
}

function loop() {
  drawWorld();
  requestAnimationFrame(loop);
}

requestAnimationFrame(loop);